import React from 'react'
import axios from 'axios'
import { useEffect, useState } from 'react'
// import { useNavigate } from "react-router-dom";
import './style.css'
// import { useEffect, useState } from 'react'
// import close from './images/close.png'
import { BsThreeDots } from 'react-icons/bs'
import Modal from './Modal'

export default function EditEpic({ emodalshow, setemodalShow }) {
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  // const[assignee,settxtUserName]=useState([]);
  const [array, setArray] = useState([])
  const [status, setStatus] = useState([])
  const [taskarray, settaskarray] = useState([])
  const[user,settxtUserName]=useState([]);
  const [eparray, setepArray] = useState([])
  const [show, setShow] = useState()
  // const[refprid,setrefprid] =useState('')
  const[Id,setid]=useState('')
  const [modalshow, setModalShow] = useState(false)
  
  // const [statarray, setstatarray] = useState([
  //   { Id: 1, Status: 'To Do' },
  //   { Id: 2, Status: 'In Progress' },
  //   { Id: 3, Status: 'Review' },
  //   { Id: 4, Status: 'Completed' },
  // ])
  const [tarray, settarray] = useState([1, 2, 3, 1, 2, 3, 1, 2, 3, 4])
var EpicId='5';
var refprid='7'
var assignee='3'
  useEffect(() => {
    //  var EpicId = localStorage.getItem('epicid')
    //  setid(EpicId)
    var url="https://9i5fv8xex0.execute-api.us-west-2.amazonaws.com/userfetch_userPage"
    var header={};
    var request = {};
    axios
      .post(url, request, header)
      .then((res) => {
        setArray(res.data);
       console.log(res.data);
      })
      .catch()
    }, []);
    function handleClick(e) {
      console.log("hi");

      var url="https://7qpodl6mw1.execute-api.us-west-2.amazonaws.com/update-epic"
   // var req ='{"txtTitle":'"title"',txtDesc:description,refprojectid:refprid}'
    // var req = '{"txtTitle":"'+ title +'","txtDesc":"'+description+'","refprojectid":"'+ refprid +'","assignee":"'+assignee+'"}'
    var req = {}
    var header = {};

    axios
    .post(url, req, header)
    .then((res) => {
      console.log(res.data);
      // setUser(res.data);
          })
    .catch((err)=>{
      console.log(err)
    });
        //alert('Success');
       // setShow(false);
  }
    // var url1 ="https://d99wuged32.execute-api.us-west-2.amazonaws.com/Epicfetch";
    // var request1 = '{"Id":"'+ EpicId +'"}';
    // var header1 = {}

    // axios
    //   .post(url1, request1, header1)
    //   .then((res) => {
    //     console.log(res.data)
    //     setepArray(res.data)
    //   })
    //   .catch((err) => {
    //     console.log(err)
    //   })
    // },[])
    //   var url2 = "https://0d7azoksze.execute-api.us-west-2.amazonaws.com/default/Taskfetch";
    // // var req2 = { Id: epicid }
    // var req2={}
    // var header2 = {};
    // axios
    //   .post(url2, req2, header2)
    //   .then((res) => {
    //     // console.log(res)
    //     settarray(res.data)
    //   })
    //   .catch(),
    // []})
    //     var url2 = 'http://localhost:8000/fetchsprintwisetasklist'
    //   var req2 = { Id: tempid }
    //   var header2 = {}
    //   axios
    //     .post(url2, req2, header2)
    //     .then((res) => {
    //       // console.log(res)
    //       settaskarray(res.data)
    //     })
    //     .catch()
  //   var url = 'http://localhost:8000/projectdetailfetchNew'
  //   var request = {}
  //   var header = {}

  //   axios
  //     .post(url, request, header)
  //     .then((res) => {
  //       setpArray(res.data)
  //       // console.log(res.data);
  //     })
  //     .catch()
  // }, [])

  // function handleClick() {
  //   console.log('hi')
  //   // var url = 'http://localhost:8000/updateEpic'
  //   var url = "https://7qpodl6mw1.execute-api.us-west-2.amazonaws.com/update-epic"
  //   var req='{"EpicName":"'+ title +'","txtDesc":"'+description+'","refassignee":"'+ assignee +'","refprojectid":"'+ refprid +'"}'
  //   // var req = {
  //     // EpicName: title,
  //     // txtDesc: description,
  //     // txtStatus: status,
  //     // name:txtName,
  //     // refassignee: 4
  
  //   var header = {}
  //   axios
  //     .post(url, req, header)
  //     .then((res) => {
  //       console.log(res.data)
  //       settxtUserName(res.data)
  //     })
  //     .catch()
  //   alert('Success')
  // }
  function ThisClick() {
    alert('cancelled!!')
  }
  function ShowClick(e) {
    e.preventDefault()
    setModalShow(modalshow ? false : true)
  }
  return (
    <>
      <Modal modalshow={modalshow} setModalShow={setModalShow} />{' '}
      <div className={emodalshow ? 'fullmodal' : 'hidden'} id="emodal">
        <div className="fullmodal_modalContent_outer">
          <div className="closeleft">
            <div
             onClick={(e)=>{setemodalShow(emodalshow?false:true)}}
              className="closeleft_container"
            >
              <label>X</label>
            </div>
          </div>
          <div className="fullmodal_modalContent">
            <div className="Epic_Taskbutton1">
              <label className="addproject_label">Edit Epic</label>
              <button className="Editepicbutton" onClick={handleClick}>
                Save
              </button>
            </div>
            {/* <div className="projectname_div">
              <label>Select Project</label>
              <select
                className="project_select"
                value={name}
                onSelect={(e) => {
                  setTextName(e.target.value)
                }}
              >
                {parray.map((item, index) => {
                  return <option value={item.txtName}>{item.txtName}</option>
                })}
              </select>
            </div> */}

            <div className="projectname_div">
              <label>Epic Name</label>
              <input
                type="text"
                value={title}
                onChange={(e) => {
                  setTitle(e.target.value)
                }}
              />
            </div>
            <div className="projectname_div">
              <label className="assignedto">Assignee</label>
              <select
                className="project_select"
                               onChange={(e) => {
                  settxtUserName(e.target.value)
                }}
              >
                {array.map((item, index) => {
                  return (
                    <>
                      <option value={item.id}>
                        {item.txtUserName}
                      </option>
                    </>
                  )
                })}
              </select>
              </div>
            {/* <div className="projectname_div">
              <label className="assignedto">AssignedTo</label>
              <select
                className="project_select"
                value={user}
                onSelect={(e) => {
                  setUser(e.target.value)
                }}
              >
                {user.map((item, index) => {
                  return (
                    <option value={item.txtUserName}>{item.txtUserName}</option>
                  )
                })}
              </select>
            </div> */}
            {/* <div
              className="projectname_div"
              id="status-select"
              onChange={(e) => {
                setStatus(e.target.value)
              }}
            >
              <label className="assignedto">Status</label>
              <select
                className="project_select"
                value={status}
                onChange={(e) => {
                  setStatus(e.target.value)
                }}
              >
                {statarray.map((stitem, stindex) => {
                  return (
                    <>
                      <option value={stitem.Status}>{stitem.Status}</option>
                    </>
                  )
                })}
              </select>
            </div> */}
            <div className="projectname_div">
              <label>Description</label>
              <textarea
                rows={4}
                value={description}
                onChange={(e) => {
                  setDescription(e.target.value)
                }}
              ></textarea>
            </div>

            <div className="button_div"></div>
            <div className="Epic_Taskbutton">
              <label className="addproject_label">Task</label>
              <button
                className="Editepicbutton"
                onClick={(e) => setShow(show ? false : true)}
              >
                Create Task
              </button>
            </div>
            <div className="main_contentbar_list">
              <div className="table_head">
                <label></label>
                <label>#id</label>
                <label>Task</label>
                <label>Assigned to</label>
                <label>Status</label>
                <label></label>
              </div>
              {tarray.map((item, index) => {
                return (
                  <div className={item == 2 ? 'row_full active' : 'row_full'}>
                    <div className="table_row">
                      <input type={'checkbox'} />
                      <label>#1006</label>
                      <label>20 Sep, 23:11</label>
                      <label>Paid</label>
                      <label>Splashify 2.0</label>
                      <div className="dropdown">
                        <label>
                          <BsThreeDots className="dropbtn" />
                        </label>
                        <div className="dropdown-content">
                          <label>Edit</label>
                          <label style={{ color: 'gray' }}>Delete</label>
                        </div>
                      </div>
                      {/* <label>
                        <BsThreeDots/>
                      </label> */}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </div>
    </>
  )
}